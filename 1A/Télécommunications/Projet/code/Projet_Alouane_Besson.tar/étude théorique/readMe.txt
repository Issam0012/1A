On avait pas trop de temps à la fin pour le projet à cause des partiels et 
les autres projets en parallèle. De ce fait, on n'a pas pu écrire l'étude théorique
en propre su laTex mais la voilà en propre même s'il est écrite à la main
